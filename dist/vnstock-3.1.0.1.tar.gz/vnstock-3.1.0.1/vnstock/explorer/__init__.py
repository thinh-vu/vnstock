from vnstock.core.utils.env import id_valid

id_valid()