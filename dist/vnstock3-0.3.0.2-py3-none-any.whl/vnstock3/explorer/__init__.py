from vnstock3.core.utils.env import id_valid

id_valid()