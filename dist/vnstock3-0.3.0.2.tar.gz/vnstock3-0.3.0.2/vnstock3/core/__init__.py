from vnai import *
from .utils.parser import *
from .utils.logger import *
from .utils.env import *

tc_init()